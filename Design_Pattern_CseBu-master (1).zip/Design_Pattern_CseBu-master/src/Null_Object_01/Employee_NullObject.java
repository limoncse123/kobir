package Null_Object_01;

public class Employee_NullObject extends AbstractEmployee{

	

	@Override
	public boolean isNull() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Not Available";
	}

}
