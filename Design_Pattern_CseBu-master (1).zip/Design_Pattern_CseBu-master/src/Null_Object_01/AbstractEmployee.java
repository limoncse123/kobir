package Null_Object_01;

public abstract class AbstractEmployee {
	protected String name;
	public abstract boolean isNull();
	public abstract String getName();

}
