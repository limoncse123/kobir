package Null_Object_01;

public class Employee_RealObject extends AbstractEmployee{

	
	
	public Employee_RealObject(String name) {
		super();
		this.name = name;
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean isNull() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
