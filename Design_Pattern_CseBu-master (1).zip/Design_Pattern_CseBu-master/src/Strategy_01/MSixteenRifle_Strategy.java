package Strategy_01;

public class MSixteenRifle_Strategy implements Strategy{

	@Override
	public String GolaGuliKorbe(String bondukName) {
		// TODO Auto-generated method stub
		String damage = "M-16 will Damage Health 40% in one shot";
		
//		String damage = bondukName+" will Damage Health 40% in one shot";
		return damage;
	}
	

}
