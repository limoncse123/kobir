package MVC_01;

public class StudentView {
	public void viewStudent(String name, String roll, String dept) {
		System.out.println("-------------------> "+name+" <-------------------");
		System.out.println(" [ Name: "+name+", Roll: "+roll+", Dept: "+dept+" ] ");
		System.out.println("---------------------------------------------------");
		System.out.println();
	}

}
