package Strategy_01;

public class AKEFourySeven_Strategy implements Strategy{
	@Override
	public String GolaGuliKorbe(String bondukName) {
		// TODO Auto-generated method stub
		String damage = "AK-47 will Damage Health 48% in one shot";
		
//		String damage = bondukName+" will Damage Health 48% in one shot";
		return damage;
	}
}
