package Strategy_01;

public interface Strategy {
	public String GolaGuliKorbe(String bondukName);

}
