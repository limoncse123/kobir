package Composite_Design_Pattern_01;

public interface Components {
	void Screen();

}
