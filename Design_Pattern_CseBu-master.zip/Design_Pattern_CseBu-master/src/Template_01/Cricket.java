package Template_01;

public class Cricket extends Game{

	@Override
	void initialize() {
		// TODO Auto-generated method stub
		System.out.println("Cricket in Initialized");
		
	}

	@Override
	void startplay() {
		// TODO Auto-generated method stub
		System.out.println("Game Started! Cricket");
	}

	@Override
	void endgame() {
		// TODO Auto-generated method stub
		System.out.println("Game Ended! Cricket");
	}
	
}
