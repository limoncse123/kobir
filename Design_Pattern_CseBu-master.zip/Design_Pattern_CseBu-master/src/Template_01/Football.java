package Template_01;

public class Football extends Game{

	@Override
	void initialize() {
		// TODO Auto-generated method stub
		System.out.println("Football in Initialized");
		
	}

	@Override
	void startplay() {
		// TODO Auto-generated method stub
		System.out.println("Game Started! Football");
	}

	@Override
	void endgame() {
		// TODO Auto-generated method stub
		System.out.println("Game Ended! Football");
	}
	

}
